#include<iostream>
#include<string>
#include"arrayListType.h"
#include"unorderedArrayListType.h"

using namespace std;

uniqueListType::uniqueListType(int size)
               : unorderedArryListType(size)
{
}

void uniqueListType::insertAt(int location, string insertItem)
{
      unorderedArrayListType n2(insertAt());
}


//void insertEnd(string insertItem);

  //    void replaceAt(int location, string repItem);


