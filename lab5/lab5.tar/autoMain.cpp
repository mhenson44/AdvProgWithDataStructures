#include"autoType.h"
#include<iomanip>

int main()
{  
   autoType fordF250;
   autoType dodgeRam(201, 10.32, 19.1);

   fordF250.setAutoSpecs(1234,16.25,25.7);
   cout << fordF250.getAutoSpecs() << endl;
   cout << "Requesting to drive 400 miles." << endl;
   fordF250.drive(400);
   cout << fordF250.getAutoSpecs() << endl;
   cout << endl;


   cout << dodgeRam.getAutoSpecs() << endl;
   cout << "Requesting to drive 400 miles." << endl;
   dodgeRam.drive(400);
   cout << dodgeRam.getAutoSpecs() << endl;
   return 0;
}
