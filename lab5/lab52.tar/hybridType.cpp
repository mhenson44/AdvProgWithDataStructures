/*
   Name:
   Date:
   Class:
   Path:

   Desc:
*/
#include<iostream>
#include"autoHybrid.h"

void hybridAutoType::setChargeLevel(int charge_in)
{
   cin >> charge_in;
}

void hybridAutoType::getChargeLevel();
{
   return charge_in;
}

void hybridAutoType::setChargeEfficiency(int chargeEff_in)
{
   cin >> chargeEff_in;
}

void hybridAutoType::getChargeEfficiency();
{
   return chargeEff_in;
}


