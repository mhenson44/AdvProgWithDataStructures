/* 
   Author:
   Date:
   Class: CSC-1720
   Code location:
   
   About: 
*/

#include"empType.h"

void empType::setName(string iname)
{
   name = iname;
}


void empType::setAge(int iage)
{
   age = iage;
}


void empType::setSalary(double isalary)
{
   salary = isalary;
}

string empType::getName(void) const
{
   return name;
}


int empType::getAge(void) const
{
   return age;
}


double empType::getSalary(void) const
{
   return salary;
}

